import { Header } from "@/components/layout/Header";
import { Hero } from "@/components/layout/Hero";
import { Features } from "@/components/layout/Features";
import { Testimonials } from "@/components/layout/Testimonials";
import { Pricing } from "@/components/layout/Pricing";
import { FAQ } from "@/components/layout/FAQ";
import { Footer } from "@/components/layout/Footer";
import { ChatInterface } from "@/components/chat/ChatInterface";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <Hero />
        <Features />
        <Testimonials />
        <Pricing />
        <FAQ />
      </main>
      <Footer />
      <ChatInterface />
    </div>
  );
}