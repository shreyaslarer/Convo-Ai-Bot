import { motion } from "framer-motion";

// Circuit board pattern that can be used as a decorative element
export const CircuitPattern = ({ className = "" }) => (
  <svg className={`${className}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
    <pattern id="circuit" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
      <path d="M1 1h18v18h-18z" fill="none" stroke="currentColor" strokeWidth="0.2"/>
      <circle cx="10" cy="10" r="1" fill="currentColor"/>
      <path d="M10 1v8M1 10h8M10 19v-8M19 10h-8" stroke="currentColor" strokeWidth="0.2"/>
    </pattern>
    <rect x="0" y="0" width="100%" height="100%" fill="url(#circuit)"/>
  </svg>
);

// Hexagonal grid pattern
export const HexPattern = ({ className = "" }) => (
  <svg className={`${className}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
    <pattern id="hex" x="0" y="0" width="15" height="26" patternUnits="userSpaceOnUse">
      <path d="M7.5 13L0 6.5 7.5 0l7.5 6.5L7.5 13zm0 13L0 19.5 7.5 13l7.5 6.5L7.5 26z" 
        fill="none" stroke="currentColor" strokeWidth="0.2"/>
    </pattern>
    <rect x="0" y="0" width="100%" height="100%" fill="url(#hex)"/>
  </svg>
);

// Data flow animation
export const DataFlow = ({ className = "" }) => {
  return (
    <div className={`relative ${className}`}>
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-neon-blue rounded-full"
          initial={{ x: 0, y: 0, opacity: 0 }}
          animate={{
            x: [0, 100, 200],
            y: [0, 50, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 3,
            delay: i * 0.2,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ))}
    </div>
  );
};

// Neural network animation
export const NeuralNetwork = ({ className = "" }) => {
  const nodes = [
    { x: 10, y: 50 },
    { x: 40, y: 30 },
    { x: 40, y: 70 },
    { x: 70, y: 50 },
  ];

  return (
    <svg className={`${className}`} viewBox="0 0 100 100">
      {nodes.map((node, i) => (
        <g key={i}>
          <circle
            cx={node.x}
            cy={node.y}
            r="3"
            className="fill-neon-blue"
          />
          {nodes.map((target, j) => {
            if (i < j) {
              return (
                <motion.path
                  key={`${i}-${j}`}
                  d={`M${node.x},${node.y} L${target.x},${target.y}`}
                  className="stroke-neon-blue/30"
                  strokeWidth="0.5"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    repeatType: "reverse",
                    ease: "linear",
                  }}
                />
              );
            }
            return null;
          })}
        </g>
      ))}
    </svg>
  );
};
