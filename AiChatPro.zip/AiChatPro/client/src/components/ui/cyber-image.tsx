import { motion } from "framer-motion";
import { CircuitPattern } from "./patterns";

interface CyberImageProps {
  src: string;
  alt: string;
  className?: string;
  width?: number;
  height?: number;
}

export function CyberImage({ src, alt, className = "", width, height }: CyberImageProps) {
  return (
    <motion.div 
      className={`relative group ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Border glow effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-neon-blue to-neon-purple opacity-0 group-hover:opacity-100 blur-lg transition-opacity duration-300" />
      
      {/* Circuit pattern overlay */}
      <div className="absolute inset-0 overflow-hidden">
        <CircuitPattern className="w-full h-full text-neon-blue opacity-20" />
      </div>
      
      {/* Actual image */}
      <img
        src={src}
        alt={alt}
        width={width}
        height={height}
        className="relative z-10 w-full h-full object-cover rounded-lg"
      />
      
      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-neon-blue rounded-tl" />
      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-neon-blue rounded-tr" />
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-neon-blue rounded-bl" />
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-neon-blue rounded-br" />
    </motion.div>
  );
}
