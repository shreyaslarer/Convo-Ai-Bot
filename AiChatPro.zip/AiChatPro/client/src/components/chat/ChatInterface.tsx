import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Send, Paperclip, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
}

export function ChatInterface() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages([...messages, newMessage]);
    setInput("");

    // TODO: Integrate with OpenAI API
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'm a demo response. OpenAI integration coming soon!",
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 1000);
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 rounded-full w-14 h-14 shadow-lg bg-gradient-to-r from-neon-blue to-neon-purple hover:shadow-[0_0_20px_rgba(0,255,239,0.5)] transition-all duration-300"
      >
        <MessageSquare className="w-6 h-6" />
      </Button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-20 right-4 w-96 z-50"
          >
            <Card className="border border-neon-blue/20 shadow-xl bg-cyber-dark/90 backdrop-blur">
              <div className="p-4 border-b border-neon-blue/20 bg-gradient-to-r from-neon-blue/10 to-neon-purple/10">
                <h3 className="font-orbitron text-white">Chat with AI Assistant</h3>
              </div>

              <div className="h-96 overflow-y-auto p-4 space-y-4 bg-cyber-black/50">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.sender === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.sender === "user"
                          ? "bg-gradient-to-r from-neon-blue to-neon-purple text-white"
                          : "bg-cyber-dark/80 border border-neon-blue/20 text-gray-300"
                      }`}
                    >
                      <p className="text-sm font-exo">{message.content}</p>
                      <span className="text-xs opacity-70 font-mono">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 border-t border-neon-blue/20 bg-cyber-dark/80">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSend()}
                    placeholder="Type your message..."
                    className="flex-1 bg-cyber-black/50 border-neon-blue/20 text-gray-300 placeholder:text-gray-500"
                  />
                  <Button 
                    onClick={handleSend}
                    className="bg-gradient-to-r from-neon-blue to-neon-purple hover:shadow-[0_0_10px_rgba(0,255,239,0.3)]"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex gap-2 mt-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-neon-blue hover:bg-neon-blue/10"
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-neon-blue hover:bg-neon-blue/10"
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}