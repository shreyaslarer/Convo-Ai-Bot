import { motion } from "framer-motion";
import { Check, Zap, Shield, Cpu, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const plans = [
  {
    name: "Starter",
    price: "Free",
    description: "Perfect for trying out our chatbot",
    icon: Zap,
    features: [
      "Up to 100 messages per month",
      "Basic chatbot customization",
      "Standard response time",
      "Email support",
      "1 chatbot instance"
    ],
  },
  {
    name: "Professional",
    price: "$49",
    description: "Ideal for growing businesses",
    icon: Shield,
    features: [
      "Up to 5,000 messages per month",
      "Advanced customization",
      "Priority response time",
      "Phone & email support",
      "Multiple chatbot instances",
      "Analytics dashboard"
    ],
    popular: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations",
    icon: Cpu,
    features: [
      "Unlimited messages",
      "Full customization",
      "Instant response time",
      "24/7 dedicated support",
      "Unlimited chatbot instances",
      "Advanced analytics",
      "Custom integrations"
    ],
  },
];

// Circuit board pattern SVG background
const CircuitPattern = () => (
  <svg className="absolute inset-0 w-full h-full opacity-5" xmlns="http://www.w3.org/2000/svg">
    <pattern id="circuit" x="0" y="0" width="50" height="50" patternUnits="userSpaceOnUse">
      <path d="M10 10h30v30h-30z" fill="none" stroke="currentColor" strokeWidth="0.5"/>
      <circle cx="25" cy="25" r="3" fill="currentColor"/>
      <path d="M25 10v12M10 25h12M25 40v-12M40 25h-12" stroke="currentColor" strokeWidth="0.5"/>
    </pattern>
    <rect x="0" y="0" width="100%" height="100%" fill="url(#circuit)"/>
  </svg>
);

export function Pricing() {
  return (
    <section className="py-20 bg-cyber-black relative overflow-hidden">
      {/* Circuit board background */}
      <CircuitPattern />

      {/* Cyber grid background */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-10" />

      <div className="container mx-auto px-4 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-white">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              Choose Your Plan
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto font-exo">
            Select the perfect plan for your business needs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card 
                className={`relative h-full bg-cyber-dark/50 backdrop-blur border-neon-blue/20 
                  hover:shadow-[0_0_20px_rgba(0,255,239,0.2)] transition-shadow duration-300
                  ${plan.popular ? 'border-neon-blue shadow-lg' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-neon-blue to-neon-purple text-white text-sm rounded-full font-orbitron">
                    Most Popular
                  </div>
                )}

                <CardHeader className="text-center pt-8">
                  <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 flex items-center justify-center mb-4">
                    <plan.icon className="w-8 h-8 text-neon-blue" />
                  </div>
                  <div className="text-2xl font-orbitron text-white mb-2">{plan.name}</div>
                  <div className="mt-4 font-orbitron">
                    <span className="text-4xl text-neon-blue font-bold">{plan.price}</span>
                    {plan.price !== "Custom" && <span className="text-gray-400">/month</span>}
                  </div>
                  <p className="text-gray-400 font-exo">{plan.description}</p>
                </CardHeader>

                <CardContent>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-gray-300 font-exo">
                        <Check className="w-5 h-5 text-neon-blue" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full bg-gradient-to-r from-neon-blue to-neon-purple hover:shadow-[0_0_20px_rgba(0,255,239,0.3)] transition-shadow duration-300"
                  >
                    {plan.price === "Custom" ? "Contact Sales" : "Get Started"}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/4 -left-20 w-40 h-40 bg-neon-blue/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-40 h-40 bg-neon-purple/20 rounded-full blur-3xl" />
      </div>
    </section>
  );
}