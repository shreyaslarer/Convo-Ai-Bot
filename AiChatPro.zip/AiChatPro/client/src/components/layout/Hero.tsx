import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { MessageSquare, Cpu, Zap } from "lucide-react";

// Particle component
const Particle = ({ delay = 0 }) => (
  <motion.div
    className="absolute w-1 h-1 bg-neon-blue rounded-full opacity-50"
    initial={{ opacity: 0 }}
    animate={{
      opacity: [0.2, 0.5, 0.2],
      scale: [1, 1.5, 1],
      y: [0, -window.innerHeight],
      x: [0, window.innerWidth],
    }}
    transition={{
      duration: 20,
      delay,
      repeat: Infinity,
      ease: "linear",
    }}
  />
);

export function Hero() {
  return (
    <div className="min-h-screen pt-16 relative overflow-hidden bg-cyber-black">
      {/* Particle system */}
      {[...Array(20)].map((_, i) => (
        <Particle key={i} delay={i * 0.5} />
      ))}

      {/* Cyber grid background */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:50px_50px] opacity-20" />

      <div className="container mx-auto px-4 relative">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.h1 
              className="font-orbitron text-4xl md:text-6xl font-bold leading-tight mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <span className="bg-gradient-to-r from-neon-blue via-purple-500 to-neon-purple bg-clip-text text-transparent animate-text-shimmer bg-[length:200%_auto]">
                Next Evolution of
              </span>
              <br />
              <span className="text-white">
                Conversational AI
              </span>
            </motion.h1>

            <motion.p 
              className="font-exo text-gray-400 text-lg mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              Experience the future of communication with our advanced AI chatbot. 
              Powered by cutting-edge technology, delivering human-like conversations 
              with machine precision.
            </motion.p>

            <motion.div 
              className="flex gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-neon-blue to-neon-purple text-white gap-2 group animate-pulse-slow hover:shadow-[0_0_20px_rgba(0,255,239,0.5)]"
              >
                <MessageSquare className="w-5 h-5 group-hover:animate-bounce" />
                Start Chat
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-neon-blue text-neon-blue hover:bg-neon-blue/10 hover:shadow-[0_0_20px_rgba(0,255,239,0.3)]"
              >
                <Cpu className="w-5 h-5 mr-2" />
                Learn More
              </Button>
            </motion.div>

            <motion.div
              className="mt-12 flex items-center gap-8 text-sm text-gray-400"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.8 }}
            >
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-neon-blue" />
                <span>Real-time Processing</span>
              </div>
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-neon-purple" />
                <span>Advanced AI Core</span>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative"
          >
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 p-8 animate-float">
              <div className="w-full h-full rounded-xl bg-cyber-dark/80 backdrop-blur shadow-lg p-6 border border-neon-blue/20">
                <div className="space-y-4">
                  <div className="flex gap-4 items-start">
                    <div className="w-8 h-8 rounded-full bg-neon-blue/20 flex items-center justify-center">
                      <MessageSquare className="w-4 h-4 text-neon-blue" />
                    </div>
                    <div className="flex-1 bg-neon-blue/10 rounded-2xl rounded-tl-none p-4">
                      <p className="text-sm text-gray-300 font-mono">
                        How can I assist you today?
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start justify-end">
                    <div className="flex-1 bg-neon-purple/10 rounded-2xl rounded-tr-none p-4">
                      <p className="text-sm text-gray-300 font-mono">
                        Tell me about your AI capabilities.
                      </p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-neon-purple/20 flex items-center justify-center">
                      <MessageSquare className="w-4 h-4 text-neon-purple" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}