import { useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "./Logo";
import { useIsMobile } from "@/hooks/use-mobile";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Features", href: "/features" },
    { label: "How It Works", href: "/how-it-works" },
    { label: "Pricing", href: "/pricing" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ];

  const NavLinks = () => (
    <>
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <span className="text-gray-400 hover:text-ai-orange transition-colors cursor-pointer">
            {item.label}
          </span>
        </Link>
      ))}
    </>
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-ai-black/80 backdrop-blur-sm border-b border-ai-orange/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Logo />

          {/* Desktop Navigation */}
          {!isMobile && (
            <nav className="hidden md:flex items-center gap-6">
              <NavLinks />
            </nav>
          )}

          <div className="flex items-center gap-4">
            <Button 
              variant="default" 
              className="hidden md:inline-flex bg-ai-orange hover:bg-ai-orange-light text-white"
            >
              Chat Now
            </Button>

            {isMobile && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-ai-orange"
              >
                {isMenuOpen ? <X /> : <Menu />}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMobile && isMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-16 left-0 right-0 bg-ai-black border-b border-ai-orange/20"
          >
            <div className="container mx-auto px-4 py-4">
              <div className="flex flex-col gap-4">
                <NavLinks />
                <Button 
                  variant="default" 
                  className="w-full bg-ai-orange hover:bg-ai-orange-light text-white"
                >
                  Chat Now
                </Button>
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}