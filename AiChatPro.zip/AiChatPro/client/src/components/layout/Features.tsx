import { motion } from "framer-motion";
import { Brain, Share2, BarChart2, Palette, MessageSquare, Lock } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { CyberImage } from "@/components/ui/cyber-image";
import { CircuitPattern, DataFlow, NeuralNetwork } from "@/components/ui/patterns";

const features = [
  {
    title: "Advanced AI Integration",
    description: "Real-time responses powered by state-of-the-art language models for natural conversations",
    icon: Brain,
    image: "/images/ai-integration.svg", 
  },
  {
    title: "Multi-Channel Support",
    description: "Seamless communication across web, mobile, and social media platforms",
    icon: Share2,
    image: "/images/multi-channel.svg",
  },
  {
    title: "Analytics Dashboard",
    description: "Comprehensive insights and performance metrics at your fingertips",
    icon: BarChart2,
    image: "/images/analytics.svg",
  },
  {
    title: "Custom Branding",
    description: "Tailor the chatbot's appearance and voice to match your brand identity",
    icon: Palette,
    image: "/images/branding.svg",
  },
  {
    title: "Smart Conversations",
    description: "Context-aware discussions with memory and learning capabilities",
    icon: MessageSquare,
    image: "/images/smart-chat.svg",
  },
  {
    title: "Enterprise Security",
    description: "Bank-grade encryption and compliance with data protection standards",
    icon: Lock,
    image: "/images/security.svg",
  },
];

export function Features() {
  return (
    <section className="py-20 bg-cyber-black relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-10" />
      <CircuitPattern className="absolute inset-0 text-neon-blue opacity-5" />

      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-white">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              Next-Gen Features
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto font-exo">
            Experience the future of communication with our cutting-edge AI technology
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full bg-cyber-dark/50 backdrop-blur border-neon-blue/20 hover:shadow-[0_0_20px_rgba(0,255,239,0.2)] transition-shadow duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-neon-blue" />
                  </div>
                  <CardTitle className="font-orbitron text-white mb-2">
                    {feature.title}
                  </CardTitle>
                  <CardDescription className="text-gray-400 font-exo mb-4">
                    {feature.description}
                  </CardDescription>
                  <div className="relative h-40 w-full overflow-hidden rounded-lg">
                    {index === 0 ? (
                      <NeuralNetwork className="absolute inset-0" />
                    ) : index === 1 ? (
                      <DataFlow className="absolute inset-0" />
                    ) : (
                      <CyberImage
                        src={feature.image}
                        alt={feature.title}
                        className="w-full h-full"
                      />
                    )}
                  </div>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/4 -left-20 w-40 h-40 bg-neon-blue/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-40 h-40 bg-neon-purple/20 rounded-full blur-3xl" />
      </div>
    </section>
  );
}