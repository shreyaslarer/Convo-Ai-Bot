import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { StarIcon } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "AI Integration Lead",
    company: "TechCorp Inc.",
    content: "The AI chatbot has revolutionized our customer support. Response times are down 70% and customer satisfaction is at an all-time high.",
    rating: 5,
    avatar: "/images/avatar-1.png", // We'll add these images later
  },
  {
    name: "Michael Chen",
    role: "Digital Innovation Director",
    company: "Global Retail",
    content: "Integration was seamless and the contextual memory feature ensures our customers get consistent, personalized responses every time.",
    rating: 5,
    avatar: "/images/avatar-2.png",
  },
  {
    name: "Emma Williams",
    role: "Startup Founder",
    company: "InnovateTech",
    content: "This chatbot has been a game-changer for our small team. It's like having a 24/7 support staff without the overhead.",
    rating: 5,
    avatar: "/images/avatar-3.png",
  },
];

export function Testimonials() {
  return (
    <section className="py-20 bg-cyber-black relative overflow-hidden">
      {/* Cyber grid background */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-10" />

      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-white">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              What Our Clients Say
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto font-exo">
            See how our AI chatbot is transforming customer service across industries
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full bg-cyber-dark/50 backdrop-blur border-neon-blue/20 hover:shadow-[0_0_20px_rgba(0,255,239,0.2)] transition-shadow duration-300">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <StarIcon
                        key={i}
                        className="w-5 h-5 text-neon-blue fill-current"
                      />
                    ))}
                  </div>
                  <p className="text-gray-300 mb-6 font-exo">{testimonial.content}</p>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 flex items-center justify-center">
                      {/* Placeholder for avatar - we'll add actual images later */}
                      <span className="text-neon-blue font-orbitron text-lg">
                        {testimonial.name[0]}
                      </span>
                    </div>
                    <div>
                      <p className="font-orbitron text-white">{testimonial.name}</p>
                      <p className="text-sm text-gray-400 font-exo">
                        {testimonial.role} at {testimonial.company}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/3 -left-20 w-40 h-40 bg-neon-purple/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 -right-20 w-40 h-40 bg-neon-blue/20 rounded-full blur-3xl" />
      </div>
    </section>
  );
}