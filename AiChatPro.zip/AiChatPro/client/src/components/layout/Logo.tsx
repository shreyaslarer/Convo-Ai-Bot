import { motion } from "framer-motion";

export function Logo() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex items-center gap-2"
    >
      <div className="relative w-10 h-10">
        <motion.img 
          src="/attached_assets/Leonardo_Phoenix_09_Design_a_modern_minimalist_logo_Create_a_s_3.jpg"
          alt="Convo AI Logo"
          className="w-full h-full object-contain"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        />
      </div>
      <span className="text-xl font-bold bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
        CONVO AI
      </span>
    </motion.div>
  );
}