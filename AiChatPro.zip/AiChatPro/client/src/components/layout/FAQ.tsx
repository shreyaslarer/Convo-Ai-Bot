import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Brain, Lock, Clock, Cog, Network } from "lucide-react";

const faqs = [
  {
    question: "How does the AI chatbot work?",
    answer: "Our AI chatbot uses advanced natural language processing to understand and respond to customer queries in real-time. It learns from conversations to provide increasingly accurate and personalized responses.",
    icon: Brain,
  },
  {
    question: "Can I customize the chatbot's responses?",
    answer: "Yes! You can customize the chatbot's personality, responses, and knowledge base to match your brand voice and specific business needs.",
    icon: Cog,
  },
  {
    question: "Is the chatbot available 24/7?",
    answer: "Yes, our chatbot operates round the clock, ensuring your customers receive immediate support at any time of day or night.",
    icon: Clock,
  },
  {
    question: "How secure is the chatbot?",
    answer: "We implement enterprise-grade security measures, including end-to-end encryption and regular security audits, to protect all conversations and data.",
    icon: Lock,
  },
  {
    question: "Can I integrate the chatbot with my existing systems?",
    answer: "Yes, our chatbot can be integrated with various CRM systems, help desks, and other business tools through our API.",
    icon: Network,
  },
];

export function FAQ() {
  return (
    <section className="py-20 bg-cyber-black relative overflow-hidden">
      {/* Cyber grid background */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-10" />

      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-white">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              Frequently Asked Questions
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto font-exo">
            Everything you need to know about our AI chatbot solution
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={faq.question}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <AccordionItem 
                  value={`item-${index}`}
                  className="border border-neon-blue/20 bg-cyber-dark/50 backdrop-blur rounded-lg overflow-hidden"
                >
                  <AccordionTrigger className="px-6 py-4 text-left hover:no-underline group">
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 flex items-center justify-center group-hover:animate-pulse">
                        <faq.icon className="w-4 h-4 text-neon-blue" />
                      </div>
                      <span className="font-orbitron text-white group-hover:text-neon-blue transition-colors">
                        {faq.question}
                      </span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 py-4 text-gray-400 font-exo">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/4 -left-20 w-40 h-40 bg-neon-blue/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-40 h-40 bg-neon-purple/20 rounded-full blur-3xl" />
      </div>
    </section>
  );
}